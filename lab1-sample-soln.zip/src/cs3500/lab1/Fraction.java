package cs3500.lab1;

/**
 * Behaviors for fractions. We assume all fractions are non-negative,
 * meaning the numerator and denominator must have the same sign.
 */
public interface Fraction {

  /**
   * Adds two non-negative fractions together and produces a new fraction with that result
   * @param frac fraction to be summed with
   * @return new fraction representing the sum of this fraction and the other specified
   */
  Fraction add (Fraction frac);

  /**
   * Adds two non-negative fractions together and produces a new fraction with that result
   * @param numerator numerator of the second fraction
   * @param denominator denominator of the second fraction
   * @return new fraction representing the sum of this fraction and the other specified
   * @throws IllegalArgumentException if exactly one of numerator, denominator is negative
   */
  Fraction add(int numerator, int denominator);

  /**
   * Returns the decimal representation of the fraction rounded up to the number of places
   * in the decimal.
   * For example, 357/505 rounded up to 2 places is 0.71.
   * @param places the number of decimal digits to be in the number
   * @return the above specified decimal number
   */
  double getDecimalValue(int places);

}
