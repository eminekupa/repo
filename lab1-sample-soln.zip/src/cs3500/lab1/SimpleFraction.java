package cs3500.lab1;

/**
 * Represent a non-negative fraction as a numerator and denominator separately.
 */
public class SimpleFraction implements Fraction {

  private final int numerator;
  private final int denominator;

  /**
   * Creates a non-negative fraction from a numerator and denominator. If both are negative,
   * the fraction removes the sign from both parts.
   * @param numerator the numerator of the fraction
   * @param denominator the denominator of the fraction
   * @throws IllegalArgumentException if exactly one of the numerator or denominator is negative
   */
  public SimpleFraction(int numerator, int denominator) {
    if(numerator < 0 && denominator >= 0) {
      throw new IllegalArgumentException("Cannot have negative fraction");
    }
    if(numerator > 0 && denominator <= 0) {
      throw new IllegalArgumentException("Cannot have negative fraction");
    }
    if(numerator < 0 && denominator < 0){
      numerator *= -1;
      denominator *= -1;
    }
    this.numerator = numerator;
    this.denominator = denominator;
  }

  //This needs to use dynamic dispatch. We don't know what the dynamic type frac is, but
  //Java does. And Fraction has ANOTHER add method that doesn't take in a fraction. So let's
  //use dynamic dispatch to call the other version of add and lead us to the correct implementation!
  @Override
  public Fraction add(Fraction frac) {
    return frac.add(this.numerator, this.denominator);
  }

  @Override
  public Fraction add(int numerator, int denominator) {
    if(numerator < 0 && denominator >= 0) {
      throw new IllegalArgumentException("Cannot have negative fraction");
    }
    if(numerator > 0 && denominator <= 0) {
      throw new IllegalArgumentException("Cannot have negative fraction");
    }
    int newNumerator = this.numerator * denominator + this.denominator * numerator;
    return new SimpleFraction(newNumerator, this.denominator * denominator);
  }

  @Override
  public double getDecimalValue(int places) {
    //Documentation says nothing about negative places, so we just default to a single place
    double powerOfTen = Math.pow(10, Math.max(1, places));
    long value = Math.round((numerator * powerOfTen)/denominator);
    return value/powerOfTen;
  }

  /**
   * Returns a human-readable representation of the fraction as numerator/denominator.
   * @return the above human-readable representation of the fraction
   */
  @Override
  public String toString() {
    return this.numerator + "/" + this.denominator;
  }
}
